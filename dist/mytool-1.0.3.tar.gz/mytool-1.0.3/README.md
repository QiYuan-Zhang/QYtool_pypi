# mytool

> My own toolbox for research projects.

---

## Python
```
. 
└── mytool
    ├── timer: give execution time of function 
    ├── datatool: for data process
    ├── dirtool: for directory operation
    ├── nntool: for neural networks, load model, save model, construct casadi model  
    ├── mathtool: for math operation
    ├── progressbar: an example to build your own custom progressbar
    └── new_wandb_proj: an example of using wandb
```

