"""
Name: progressbar.py
Author: Xuewen Zhang
Date:at 28/04/2024
version: 1.0.0
Description: my own toolbox for research projects
"""

from rich.progress import (
    BarColumn,
    DownloadColumn,
    Progress,
    TaskID,
    TextColumn,
    TimeRemainingColumn,
    TransferSpeedColumn,
    TimeElapsedColumn,
    TaskProgressColumn,
    MofNCompleteColumn,
    SpinnerColumn,
    RenderableColumn,
)


def progressbar():
    """ Customized progress bar"""
    progress = Progress(
        TextColumn(":hourglass_done: [progress.description]{task.description}"),
        # SpinnerColumn(),
        TaskProgressColumn(),  # percentage
        BarColumn(),           # progress bar
        MofNCompleteColumn(),  # i/total
        TimeElapsedColumn(),   # time elapsed
        TextColumn("<"),       # add a '<' symbol
        TimeRemainingColumn(), # time remaining
        TextColumn("loss:[progress.loss]{task.fields[loss]:.5f}"), # add wanted information
    )
    return progress



if __name__ == "__main__":

    with progress:
        task1 = progress.add_task(description="[red]Downloading...", total=100, loss=0.0)
        i = 0
        while not progress.finished:
            i += 1
            loss = i * 0.001
            progress.update(task1, loss=loss, advance=1)
            time.sleep(0.02)